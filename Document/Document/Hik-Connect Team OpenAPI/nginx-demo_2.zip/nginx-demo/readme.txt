1. Double-click nginx.exe to start the web server
2. Browser access demo.html to use demo, such as: 127.0.0.1/demo.html
3. The demo file is in the html folder